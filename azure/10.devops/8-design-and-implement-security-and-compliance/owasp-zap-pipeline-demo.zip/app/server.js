const express = require('express');
const app = express();

const port = process.env.PORT || 8080;

// Very simple routes so ZAP has something to crawl
app.get('/', (_req, res) => res.type('html').send(`
  <h1>OWASP ZAP Demo</h1>
  <ul>
    <li><a href="/about">About</a></li>
    <li><a href="/contact?email=test@example.com">Contact</a></li>
  </ul>
`));

app.get('/about', (_req, res) => res.json({ app: 'zap-demo', ok: true }));
app.get('/contact', (req, res) => {
  res.send(`Thanks! We'll contact: ${req.query.email || 'nobody'}`);
});

app.listen(port, () => console.log(`Demo app listening on ${port}`));
