# 🔒 OWASP ZAP CI/CD Demo (Azure DevOps)

This repo shows a **full multi-stage Azure Pipelines project** that:
- Builds a small Node.js web app.
- **Deploys to Dev**, then
- **Runs OWASP ZAP (Docker baseline scan)** against the Dev URL.
- Saves results to **Azure Storage** (Create Storage → Create Container → Upload).
- **Downloads**, **transforms** results to **JUnit + SARIF**, **publishes** reports, and **fails** if High/Medium findings exist.
- Optionally **deletes the container**.
- If ZAP passes → **Deploys to Production**.

## 🗂 Structure
```
/app                 # Demo web app (Node/Express)
/tools               # ZAP utilities (evaluate+transform)
azure-pipelines.yml  # Multi-stage CI/CD
```

## 🧱 Stages & Jobs
- **Stage: Build**
  - Build & package `app.zip` artifact.

- **Stage: Development**
  - **Deploy** → ensure RG/Plan/WebApp and deploy `app.zip` to Dev.
  - **Create Storage** → ensure Storage Account + Blob Container.
  - **Run ZAP Scan** → `owasp/zap2docker-stable` baseline scan; produce HTML/JSON/XML.
  - **Download/Transform/Publish** → Convert JSON to JUnit & SARIF (`tools/zap_eval.py`); publish artifacts + test results.
  - **Delete Container** → optional cleanup.

- **Stage: Production**
  - Deploy to Prod **only if** Development succeeded (i.e., ZAP thresholds passed).

## ⚙️ One-time Setup
1. Create an **Azure Resource Manager service connection** in Azure DevOps named `sc-azure`.
2. Make sure that connection can **create RG/plan/webapps** and **has Storage Blob Data Contributor** on the Storage Account.
3. In `azure-pipelines.yml` adjust variables to your naming:
   ```yaml
   variables:
     storageAccount: 'zapdemostorage1234'   # must be globally unique
     devWebAppName: 'zap-demo-web-dev'      # globally unique
     prodWebAppName: 'zap-demo-web-prod'    # globally unique
   ```

## 🚦 ZAP Gate (fail conditions)
The pipeline transforms ZAP JSON and fails the job when:
- **Any High** severity issue exists, or
- **Any Medium** severity issue exists.
You can relax thresholds in `tools/zap_eval.py` call:
```bash
--fail-high --max-medium 0 --max-low 9999
```

## 📊 Outputs
- `zap-raw` artifact → original `zap_report.html/json/xml`.
- `zap-processed` artifact → `zap-junit.xml` + `zap.sarif`.
- Test tab shows **JUnit** failures for Medium/High alerts.

## 🧪 Local ZAP run (optional)
```bash
cd tools
./run_zap.sh https://your-dev-url.azurewebsites.net ../local-zap-out
python3 zap_eval.py --json ../local-zap-out/zap_report.json --junit junit.xml --sarif zap.sarif --fail-high --max-medium 0
```

## 🔐 Notes
- The pipeline uses **Docker** on `ubuntu-latest`. Ensure your org allows it.
- Storage commands use `--auth-mode login`. The service connection identity must have **Storage Blob Data Contributor** role.
- Active scans can be noisy; this demo uses the **baseline** scan (safe). Switch to `zap-full-scan.py` for deeper testing in non-prod.
