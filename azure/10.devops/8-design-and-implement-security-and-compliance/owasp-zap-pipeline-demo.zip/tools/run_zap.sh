#!/usr/bin/env bash
set -euo pipefail
TARGET_URL="${1:-http://localhost:8080}"
OUT_DIR="${2:-./zap-out}"
mkdir -p "$OUT_DIR"
docker run --rm -t -v "$(pwd)/${OUT_DIR}:/zap/wrk" owasp/zap2docker-stable       zap-baseline.py -t "$TARGET_URL" -r zap_report.html -J zap_report.json -x zap_report.xml -m 5 -d
echo "Reports in $OUT_DIR"
