#!/usr/bin/env python3
import argparse, json, sys, xml.etree.ElementTree as ET, hashlib, time

def load_alerts(json_path):
    with open(json_path, 'r') as f:
        data = json.load(f)
    alerts = []
    sites = data.get('site', [])
    # Some reports wrap sites under 'OWASPZAPReport'
    if isinstance(data, dict) and 'OWASPZAPReport' in data:
        sites = data['OWASPZAPReport'].get('site', [])
    if not isinstance(sites, list):
        sites = [sites]
    for site in sites:
        site_name = site.get('@name') or site.get('name') or site.get('host') or 'site'
        site_alerts = site.get('alerts', [])
        if not isinstance(site_alerts, list):
            site_alerts = site_alerts.get('alertitem', site_alerts) or []
        for a in site_alerts:
            # Normalize fields from various ZAP JSON formats
            name = a.get('alert') or a.get('name') or 'alert'
            riskcode = a.get('riskcode') or a.get('riskCode') or a.get('risk', '0')
            try:
                riskcode = int(str(riskcode).split()[0].replace('(', '').replace(')', ''))
            except:
                # Map from text
                riskdesc = (a.get('riskdesc') or a.get('riskDesc') or '').lower()
                if 'high' in riskdesc: riskcode = 3
                elif 'medium' in riskdesc: riskcode = 2
                elif 'low' in riskdesc: riskcode = 1
                else: riskcode = 0
            risktext = {3:'High',2:'Medium',1:'Low',0:'Informational'}.get(riskcode, 'Unknown')
            url = a.get('url') or a.get('uri') or ''
            param = a.get('param') or ''
            desc = a.get('desc') or a.get('description') or ''
            solution = a.get('solution') or ''
            evidence = a.get('evidence') or ''
            alerts.append({
                'site': site_name,
                'name': name,
                'riskcode': riskcode,
                'risk': risktext,
                'url': url,
                'param': param,
                'desc': desc,
                'solution': solution,
                'evidence': evidence
            })
    return alerts

def write_junit(alerts, path):
    ts = ET.Element('testsuite', {
        'name': 'OWASP ZAP Alerts',
        'tests': str(len(alerts) or 1),
        'failures': str(sum(1 for a in alerts if a['riskcode']>=2)),
        'timestamp': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    })
    if not alerts:
        ET.SubElement(ts, 'testcase', {'classname':'zap','name':'NoAlerts'})
    for a in alerts:
        tc = ET.SubElement(ts, 'testcase', {
            'classname': a['site'],
            'name': f"{a['risk']} - {a['name']}"
        })
        if a['riskcode']>=2:
            msg = f"{a['risk']} issue at {a['url']} param={a['param']}: {a['name']}\n{a['desc']}\nSolution: {a['solution']}"
            fail = ET.SubElement(tc, 'failure', {'message': msg})
            fail.text = a['evidence'] or ''
    ET.ElementTree(ts).write(path, encoding='utf-8', xml_declaration=True)

def write_sarif(alerts, path):
    # Minimal SARIF v2.1.0
    rules = {}
    results = []
    for a in alerts:
        rule_id = "ZAP-" + hashlib.sha1(a['name'].encode('utf-8')).hexdigest()[:8]
        rules[rule_id] = {
            "id": rule_id,
            "name": a['name'],
            "shortDescription": {"text": a['name']},
            "fullDescription": {"text": a['desc'] or a['name']},
            "help": {"text": a['solution'] or ""},
            "defaultConfiguration": {"level": "error" if a['riskcode']>=2 else "note"}
        }
        results.append({
            "ruleId": rule_id,
            "level": "error" if a['riskcode']>=2 else ("warning" if a['riskcode']==1 else "note"),
            "message": {"text": f"{a['risk']} - {a['name']} {a['url']} {a['param']}"},
            "locations": [{
                "physicalLocation": {
                    "artifactLocation": {"uri": a['url'] or "N/A"}
                }
            }]
        })
    sarif = {
        "version": "2.1.0",
        "$schema": "https://schemastore.azurewebsites.net/schemas/json/sarif-2.1.0.json",
        "runs": [{
            "tool": {"driver": {"name": "OWASP ZAP", "rules": list(rules.values())}},
            "results": results
        }]
    }
    with open(path, 'w') as f:
        json.dump(sarif, f, indent=2)

def main():
    ap = argparse.ArgumentParser(description="Evaluate ZAP JSON and output JUnit/SARIF; fail on thresholds.")
    ap.add_argument('--json', required=True)
    ap.add_argument('--junit', required=True)
    ap.add_argument('--sarif', required=True)
    ap.add_argument('--max-low', type=int, default=9999)
    ap.add_argument('--max-medium', type=int, default=0)
    ap.add_argument('--fail-high', action='store_true')
    args = ap.parse_args()

    alerts = load_alerts(args.json)
    highs = sum(1 for a in alerts if a['riskcode']==3)
    meds  = sum(1 for a in alerts if a['riskcode']==2)
    lows  = sum(1 for a in alerts if a['riskcode']==1)

    write_junit(alerts, args.junit)
    write_sarif(alerts, args.sarif)

    print(f"ZAP alerts: High={highs} Medium={meds} Low={lows}")
    should_fail = (args.fail_high and highs>0) or (meds>args.max_medium) or (lows>args.max_low)
    sys.exit(1 if should_fail else 0)

if __name__ == "__main__":
    main()
